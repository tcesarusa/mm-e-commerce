[
	[1,"The Shawshank Redemption",1994,678790,9.2,1],
	[2,"The Godfather",1972,511495,9.2,2]
]