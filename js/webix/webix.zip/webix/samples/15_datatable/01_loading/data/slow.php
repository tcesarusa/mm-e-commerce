<?php
	sleep(2);
	echo file_get_contents("./data.json");
?>